Quick Install:
1. Copy *.ret files to {user_account_path}\Documents\My Business Objects Documents\templates.
2. Open command prompt (in Vista as Administrator).
3. Run TPIDE_BOIntf.exe

Note! Before creating reports, start one instance of BusinessObjects.